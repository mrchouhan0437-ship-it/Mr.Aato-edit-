# AutoEdit AI Android v0.2

## इस वर्जन में
- कैमरे से वीडियो रिकॉर्ड करने का विकल्प
- गैलरी से वीडियो चुनना
- वीडियो प्रीव्यू
- शुरुआत और अंत का समय सेकंड में डालकर वीडियो trim/export करना (Media3 Transformer)

## अभी नहीं
AI smart cuts, speech-to-text subtitles, music selection/mixing और 9:16 crop अभी शामिल नहीं हैं।
ये अगले चरण हैं। इस prototype का export ऐप के private Movies folder में सेव होता है।

## Build
1. Android Studio में यह folder खोलें।
2. Gradle sync करें (इंटरनेट चाहिए ताकि Media3 dependencies डाउनलोड हों)।
3. Android SDK 35 इंस्टॉल करें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`

Package: `com.autoeditai.app`
