package com.autoeditai.app

import android.app.Activity
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.TextView
import android.widget.VideoView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

class MainActivity : ComponentActivity() {
    private var selectedUri: Uri? = null
    private var durationMs: Long = 0L
    private var transformer: Transformer? = null
    private lateinit var status: TextView
    private lateinit var preview: VideoView
    private lateinit var startInput: EditText
    private lateinit var endInput: EditText
    private lateinit var exportButton: Button

    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) showVideo(uri)
    }

    private val recordVideo = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { showVideo(it) }
                ?: run { status.text = "Recording saved. Choose it from Gallery to edit." }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            gravity = Gravity.TOP
            setBackgroundColor(0xFF101426.toInt())
        }
        page.addView(TextView(this).apply {
            text = "AutoEdit AI"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
        })
        page.addView(TextView(this).apply {
            text = "Version 0.2  •  Select, trim and export"
            textSize = 13f
            setTextColor(0xFFB8BBD0.toInt())
            setPadding(0, 4, 0, 18)
        })
        page.addView(actionButton("🎥  Record video") { openCamera() })
        page.addView(actionButton("＋  Choose video") { pickVideo.launch("video/*") })

        status = TextView(this).apply {
            text = "Choose a video to begin."
            textSize = 14f
            setTextColor(0xFFE7E8F2.toInt())
            setPadding(0, 14, 0, 10)
        }
        page.addView(status)

        preview = VideoView(this).apply {
            setBackgroundColor(0xFF252B40.toInt())
            visibility = View.GONE
        }
        page.addView(preview, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 220
        ))

        page.addView(sectionLabel("TRIM VIDEO"))
        page.addView(TextView(this).apply {
            text = "Start time (seconds)"
            setTextColor(0xFFD9DCEF.toInt())
        })
        startInput = EditText(this).apply {
            hint = "0"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText("0")
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF858BA5.toInt())
        }
        page.addView(startInput)
        page.addView(TextView(this).apply {
            text = "End time (seconds)"
            setTextColor(0xFFD9DCEF.toInt())
        })
        endInput = EditText(this).apply {
            hint = "Video duration"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF858BA5.toInt())
        }
        page.addView(endInput)
        exportButton = actionButton("✂  Export trimmed video") { exportTrimmedVideo() }
        exportButton.isEnabled = false
        page.addView(exportButton)
        page.addView(sectionLabel("COMING NEXT"))
        page.addView(infoLine("• Auto Hindi / English subtitles"))
        page.addView(infoLine("• 9:16 Reels crop and background music"))
        page.addView(infoLine("• AI smart cuts and automatic highlights"))
        setContentView(page)
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 15f
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun sectionLabel(label: String) = TextView(this).apply {
        text = label
        textSize = 12f
        setTextColor(0xFF9FA5C2.toInt())
        setPadding(0, 18, 0, 8)
    }

    private fun infoLine(label: String) = TextView(this).apply {
        text = label
        textSize = 13f
        setTextColor(0xFFD9DCEF.toInt())
        setPadding(0, 4, 0, 4)
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_VIDEO_CAPTURE)
        if (intent.resolveActivity(packageManager) != null) recordVideo.launch(intent)
        else Toast.makeText(this, "Camera app not found.", Toast.LENGTH_LONG).show()
    }

    private fun showVideo(uri: Uri) {
        selectedUri = uri
        durationMs = try {
            MediaMetadataRetriever().run {
                setDataSource(this@MainActivity, uri)
                val d = extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                release()
                d
            }
        } catch (_: Exception) { 0L }

        val seconds = durationMs / 1000.0
        endInput.setText(if (seconds > 0) String.format(java.util.Locale.US, "%.1f", seconds) else "")
        status.text = if (seconds > 0) "Video loaded • ${"%.1f".format(seconds)} seconds" else "Video loaded. Duration could not be read."
        preview.visibility = View.VISIBLE
        preview.setVideoURI(uri)
        preview.setMediaController(MediaController(this).also { it.setAnchorView(preview) })
        preview.start()
        exportButton.isEnabled = true
    }

    private fun exportTrimmedVideo() {
        val uri = selectedUri ?: return
        val startMs = ((startInput.text.toString().toDoubleOrNull() ?: 0.0) * 1000).toLong()
        val endMs = ((endInput.text.toString().toDoubleOrNull() ?: (durationMs / 1000.0)) * 1000).toLong()

        if (startMs < 0 || endMs <= startMs || (durationMs > 0 && endMs > durationMs + 500)) {
            Toast.makeText(this, "Enter a valid start and end time.", Toast.LENGTH_LONG).show()
            return
        }

        val outputDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        val outputFile = File(outputDir, "AutoEdit_${System.currentTimeMillis()}.mp4")
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs)
            .setEndPositionMs(endMs)
            .build()
        val mediaItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(clipping)
            .build()
        val editedItem = EditedMediaItem.Builder(mediaItem).build()

        exportButton.isEnabled = false
        status.text = "Exporting video… Please keep the app open."
        transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                    runOnUiThread {
                        status.text = "Export complete! Saved inside AutoEdit AI app storage: ${outputFile.name}"
                        exportButton.isEnabled = true
                        Toast.makeText(this@MainActivity, "Video exported.", Toast.LENGTH_LONG).show()
                    }
                }

                override fun onError(
                    composition: androidx.media3.transformer.Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    runOnUiThread {
                        status.text = "Export failed: ${exportException.message ?: "Unknown error"}"
                        exportButton.isEnabled = true
                    }
                }
            })
            .build()
        transformer?.start(editedItem, outputFile.absolutePath)
    }
}
